package Learner;

public class Learner {
    int learnerId;
    String name;
    String gender;
    String age;
    String emContactNumber;
    int currentGradeLevel;
    String coachId;

    public int getLearnerId() {
        return learnerId;
    }

    public String getName() {
        return name;
    }

    public String getGender() {
        return gender;
    }

    public String getAge() {
        return age;
    }

    public String getEmContactNumber() {
        return emContactNumber;
    }

    public int getCurrentGradeLevel() {
        return currentGradeLevel;
    }

    public void setLearnerId(int learnerId) {
        this.learnerId = learnerId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public void setEmContactNumber(String emContactNumber) {
        this.emContactNumber = emContactNumber;
    }

    public void setCurrentGradeLevel(int currentGradeLevel) {
        this.currentGradeLevel = currentGradeLevel;
    }

    public String getCoachId() {
        return coachId;
    }

    public void setCoachId(String coachId) {
        this.coachId = coachId;
    }

    public Learner(int learnerId, String name, String gender, String age, String emContactNumber, int currentGradeLevel) {
        this.learnerId = learnerId;
        this.name = name;
        this.gender = gender;
        this.age = age;
        this.emContactNumber = emContactNumber;
        this.currentGradeLevel = currentGradeLevel;
    }

    public Learner(int learnerId, String name, String gender, String age, String emContactNumber, int currentGradeLevel, String coachId) {
        this.learnerId = learnerId;
        this.name = name;
        this.gender = gender;
        this.age = age;
        this.emContactNumber = emContactNumber;
        this.currentGradeLevel = currentGradeLevel;
        this.coachId = coachId;
    }
}
